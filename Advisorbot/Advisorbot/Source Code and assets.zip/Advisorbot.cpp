// Advisorbot.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <fstream>
#include "Main.h"
using namespace std;

int main()
{
	Main app;
	app.Init();
}